#include "nodoFila.h"

NodoFila::NodoFila(int idCliente) {
	this->idCliente = idCliente;
	siguiente = NULL;
}

